export const handler = () => ({ foo: 'bar' });
